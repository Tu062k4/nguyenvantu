package com.example.welcomeapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WelcomeappApplication {
    public static void main(String[] args) {
        SpringApplication.run(WelcomeappApplication.class, args);
    }
}
